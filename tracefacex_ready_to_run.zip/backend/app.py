from flask import Flask, request, jsonify
from flask_cors import CORS
import face_recognition
from PIL import Image
import io

app = Flask(__name__)
CORS(app)

@app.route('/api/detect', methods=['POST'])
def detect_face():
    if 'image' not in request.files:
        return jsonify({'message': 'No image provided'}), 400

    file = request.files['image']
    img_bytes = file.read()
    image = face_recognition.load_image_file(io.BytesIO(img_bytes))

    face_locations = face_recognition.face_locations(image)

    if len(face_locations) == 0:
        return jsonify({'message': '❌ No face detected'}), 200
    else:
        return jsonify({'message': f'✅ {len(face_locations)} face(s) detected'}), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
